<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MyBloc</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>MyBlog</title>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
</head>
<body id="body">
<div id="page" class="hfeed">
  <header id="branding" role="banner">
      <?php
      include "header.html"
      ?>
  </header>
    <h1 style="margin-top: 50px; margin-bottom: 50px; font-size: 40px; text-align: center">Still Constructing...</h1>
  <footer>
      <?php
      include "footer.html"
      ?>
  </footer>
</div>
</body>
</html>