<div>
    <div class="m-daily-log">
        <div class="log-classify">php页面样例</div>
        <div class="log-link"><a href="article/article_detail.php?article=article">学院召开研究生期中教学检查座谈会</a></div>
        <div class="log-date">2021-05-20</div>
    </div>
    <div class="m-daily-log">
        <div class="log-classify">Personal Log</div>
        <div class="log-link"><a href="">Summary</a></div>
        <div class="log-date">2021-05-20</div>
    </div>
    <div class="m-daily-log">
        <div class="log-classify">Personal Log</div>
        <div class="log-link"><a href="">Summary</a></div>
        <div class="log-date">2021-05-20</div>
    </div>
    <div class="m-daily-log">
        <div class="log-classify">Personal Log</div>
        <div class="log-link"><a href="">Summary</a></div>
        <div class="log-date">2021-05-20</div>
    </div>
    <p style="text-align: center; ">####文章列表php自动生成功能建设中####</p>
</div>
